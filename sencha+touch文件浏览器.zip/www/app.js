Ext.Loader.setConfig({ enabled:true })
Ext.Loader.setPath({
    'xanxus':'app'
});
var container,fileSystem,fileStore,fileList,currentPath,isFirstLoad=true;
Ext.application({
    name:'xanxus',
    controllers:['main'],

    launch:function () {
        fileStore=Ext.create('Ext.data.Store',{
            fields:[{name:'fileName',type:'string'},{name:'fileIcon',type:'string'}],
            sorters:'fileName'
        });
        container = Ext.create('Ext.Container', {
            fullscreen:true,
            activeItem:0,
            layout:{
                type:'card',
                animation:{
                    type:'slide',
                    direction:'right'
                }
            },
            items:[
                {
                    xtype:'homepage'
//                        text:'hello'
                },
                Ext.create('xanxus.view.fileList')
            ]
        })
    }
})
