/**
 * Created with JetBrains WebStorm.
 * User: xanxus
 * Date: 12-6-23
 * Time: 下午3:40
 * To change this template use File | Settings | File Templates.
 */
Ext.define('xanxus.controller.main', {
    extend:'Ext.app.Controller',
    views:['home', 'fileList'],
    config:{
        control:{
            'button[action=returnHome]':{
                tap:'returnHome'
            },
            'button[action=chooseFile]':{
                tap:'chooseFile'
            }
        }
    },
    returnHome:function () {
        container.getLayout().setAnimation({
            type:'slide',
            direction:'left'
        });
        container.setActiveItem(0);
    },
    chooseFile:function () {
        //当前路径的文件名读写
        var dirReader;
        container.getLayout().setAnimation({
            type:'slide',
            direction:'right'
        });
        container.setActiveItem(1);
        //删除之前的文件列表
        container.items.items[1].remove(fileList);
        fileList = Ext.create('Ext.dataview.List', {
            store:fileStore,
            styleHtmlContent:true,
            itemTpl:'<img src="resources/images/{fileIcon}.png" alt="{fileIcon}"/><strong>{fileName}</strong>',
            flex:9,
            listeners:{
                itemtap:function (view, index, target, record, e, eOpts) {
                    itemName = record.get('fileName');
                    if (itemName == "...上一级") {
                        parentPath = currentPath.substring(0, currentPath.lastIndexOf('/'));
                        parentName = parentPath.substring(parentPath.lastIndexOf('/') + 1);
                        parentEntry = new DirectoryEntry(parentName, parentPath);
                        currentPath = parentPath;
                        dirReader = parentEntry.createReader();
                        dirReader.readEntries(getFiles, onError);
                    }
                    else {
                        parentEntry = new DirectoryEntry(itemName, currentPath + '/' + itemName);
                        fileType = itemName.substring(itemName.lastIndexOf('.') + 1);
                        if (parentEntry.isDirectory && fileType != "pdf") {
                            currentPath = currentPath + '/' + itemName;
                            dirReader = parentEntry.createReader();
                            dirReader.readEntries(getFiles, onError); 
                        }
                        //如果是pdf文件则交给pdf插件处理
                        else {
//                        window.plugins.message.Toast(onSuccess, onError, fileType);
                            pdfPath = currentPath.substring(currentPath.indexOf(':') + 3);
                            pdfPath = pdfPath + '/' + itemName;
                            window.plugins.pdfView.showPdf(onSuccess, onError, pdfPath);
                        }
                    }
                }
            }
        });

        if (isFirstLoad) {
            document.addEventListener("deviceready", onDeviceReady, false);
            isFirstLoad = false;
        }
        function onDeviceReady() {
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onFSuccess, onError);
        }

        function onFSuccess(fs) {
            fileSystem = fs;
            currentPath = fileSystem.root.fullPath;
            currentPathName = currentPath.substring(currentPath.lastIndexOf('/') + 1);
            dirReader = fileSystem.root.createReader();
            dirReader.readEntries(getFiles, onError);
//            dirReader = new DirectoryEntry(currentPathName, currentPath).createReader();
//            dirReader.readEntries(getFiles, onError);
        }

        function onError(e) {
//            alert(e.toString());
            alert(e.toString());
        }

        function onSuccess(result) {
            console.log(result.toString());
        }

        function getFiles(entries) {
            //把当前fileList里的记录删除掉
            fileList.getStore().removeAll();
            showPath = "当前位置是：" + currentPath.substring(currentPath.indexOf(':') + 3);
            Ext.getCmp('currentPath').setHtml(showPath);

            for (var i = 0; i < entries.length; i++) {
                //文件夹显示
                if (entries[i].isDirectory) {
                    fileList.getStore().add({
                        'fileName':entries[i].name,
                        'fileIcon':'folder'
                    })
                }
                else {
                    fileName = entries[i].name;
                    fileType = fileName.substring(fileName.lastIndexOf('.') + 1);
                    //pdf文件才显示
                    if (fileType == "pdf") {
                        fileList.getStore().add({
                            'fileName':fileName,
                            'fileIcon':'pdf'
                        })
                    }
                }
            }
            //加入上一级项目
            if (currentPath != 'file:///mnt/sdcard') {
                fileList.getStore().insert(0, {
                    'fileName':'...上一级',
                    'fileIcon':'upfolder'
                })
            }
        }

        //插入当前路径下的文件列表
        container.items.items[1].add(fileList);
    }
})