/**
 * Created with JetBrains WebStorm.
 * User: xanxus
 * Date: 12-6-23
 * Time: 下午3:24
 * To change this template use File | Settings | File Templates.
 */
Ext.define('xanxus.view.fileList',{
    extend:'Ext.Panel',
    xtype:'fileList',
    config:{
//        fullscreen:true,
        layout:{
            type:'vbox',
//            align:'center',
            pack:'center'
        },
       defaults:{
           flex:1
       },
        items:[
            {
                xtype:'titlebar',
                title:'选择要阅读的pdf',
                docked:'top'
            },
            {
                xtype:'label',
                id:'currentPath',
                html:'当前位置是：'
            },
            {
                xtype:'button',
                text:'返回首页',
                action:'returnHome',
                ui:'action',
//                width:'30%',
                docked:'bottom'
            }
        ]
    }
})