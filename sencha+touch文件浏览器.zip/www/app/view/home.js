/**
 * Created with JetBrains WebStorm.
 * User: xanxus
 * Date: 12-6-23
 * Time: 下午3:43
 * To change this template use File | Settings | File Templates.
 */
Ext.define('xanxus.view.home', {
    extend:'Ext.Panel',
    xtype:'homepage',
    config:{
//        fullscreen:true,
        layout:{
            type:'vbox',
            pack:'center',
            align:'center'
        },
        defaults:{
            xtype:'button',
            margin:'10',
            ui:'action'
        },
        items:[
//            {
//                text:'alert',
//                handler:function () {
//                    navigator.notification.alert(
//                        'You are the winner!', // 显示信息
//                        alertDismissed, // 警告被忽视的回调函数
//                        'Game Over', // 标题
//                        'Done' // 按钮名称   'You are the winner!',  // 显示信息
//                    )
//                    function alertDismissed() {
//
//                    }
//
////                        Ext.Msg.alert('Game Over', 'You are the winner!');
//                }
//            },
//            {
//                text:'vibrate',
//                handler:function () {
//                    document.addEventListener("deviceready",
//                        onDeviceReady, false);
//                    function onDeviceReady() {
//                        navigator.notification.vibrate(2000);
//                    }
//                }
//            },
//            {
//                text:'beep',
//                handler:function () {
//                    document.addEventListener("deviceready",
//                        onDeviceReady, false);
//                    function onDeviceReady() {
//                        navigator.notification.beep(1);
//                    }
//                }
//            },
//            {
//                text:'camera',
//                handler:function () {
//                    document.addEventListener("deviceready",
//                        onDeviceReady, false);
//                    //图片来源，图片返回值的格式
//                    var pictureSource, destinationType;
//
//                    function onDeviceReady() {
//                        pictureSource = navigator.camera.PictureSourceType;
//                        destinationType = navigator.camera.DestinationType;
//                        navigator.camera.getPicture(onPhotoDataSuccess, onError,
//                            {quality:50, destinationType:destinationType.DATA_URL});
//                    }
//
//                    // 当成功获得一张照片的Base64编码数据后被调用
//                    function onPhotoDataSuccess(imageData) {
//                        alert('imageData');
//                        console.log(imageData);
//                        //获得图像句柄
//                        var img = document.getElementById('smallImage');
//                        //取消隐藏图像元素
//                        img.style.display = 'block';
//                        //显示拍摄的图片，使用内嵌的css来缩放图片
//                        img.src = "data:image/jpeg;base64," + imageData;
//                    }
//
//                    // 当成功得到一张照片的URI后被调用
//                    function onPhotoURLSuccess(imageUrl) {
//                        console.log(imageUrl);
//                        var largeImage = Ext.get('largeImage');
//                        largeImage.style.display = 'block';
//                        largeImage.src = imageUrl;
//                    }
//
//                    function onError(message) {
//                        alert("Fail reason: " + message);
//                    }
//                }
//            },
//            {
//                text:'native method',
//                handler:function () {
//                    document.addEventListener("deviceready", onDeviceReady, false);
//                    function onDeviceReady() {
////                            window.plugins.message.Toast(onSuccess(),onError(),"hello,world");
//                        window.plugins.message.Toast(onSuccess, onError, "hello,world");
//                    }
//
//                    function onSuccess(result) {
////                            alert('success: \r\n'+result);
//                    }
//
//                    function onError(result) {
////                            alert('error: \r\n'+result);
//                    }
//                }
//            },
            {
                text:'open file explorer',
                action:'chooseFile'
            }
        ]
    }
})